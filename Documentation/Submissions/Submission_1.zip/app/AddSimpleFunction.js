(function () {
    "use strict";

    var obj = {
        add: function (a,b) {
            return a+b;
        }

    }

    module.exports = obj;

}());
